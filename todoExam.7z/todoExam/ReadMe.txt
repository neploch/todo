# Introduction
This short Selenium WebDriver based project implements a simple 